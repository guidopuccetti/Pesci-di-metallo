Place artwork images in this folder. Example: untitled-1.jpg
